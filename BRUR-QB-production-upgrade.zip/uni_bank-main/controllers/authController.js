const crypto = require("crypto");
const { getJwtSecret } = require("../config/env");

/**
 * Constant-time string comparison, so checking the admin
 * password doesn't leak timing information.
 */
function safeCompare(a, b) {
  const bufferA = Buffer.from(String(a));
  const bufferB = Buffer.from(String(b));

  if (bufferA.length !== bufferB.length) {
    // Still run a comparison so the response time doesn't
    // reveal the correct password's length.
    crypto.timingSafeEqual(bufferA, bufferA);
    return false;
  }

  return crypto.timingSafeEqual(bufferA, bufferB);
}

/**
 * POST /api/auth/admin-login
 * body: { password }
 */
async function adminLogin(req, res) {
  const { password } = req.body || {};
  const adminPassword = process.env.ADMIN_PASSWORD;

  if (!adminPassword) {
    console.error(
      "ADMIN_PASSWORD is not set in the environment. Admin login is disabled."
    );

    return res.status(500).json({
      success: false,
      message: "Admin login is not configured on the server.",
    });
  }

  if (!password || !safeCompare(password, adminPassword)) {
    return res.status(401).json({
      success: false,
      message: "Incorrect password.",
    });
  }

  let jwtSecret;
  try {
    jwtSecret = getJwtSecret();
  } catch {
    return res.status(503).json({
      success: false,
      message: "Admin authentication is not securely configured.",
    });
  }

  const now = Math.floor(Date.now() / 1000);
  const encode = (value) => Buffer.from(JSON.stringify(value)).toString("base64url");
  const unsigned = `${encode({ alg: "HS256", typ: "JWT" })}.${encode({ role: "admin", iat: now, exp: now + 12 * 60 * 60 })}`;
  const signature = crypto.createHmac("sha256", jwtSecret).update(unsigned).digest("base64url");
  const token = `${unsigned}.${signature}`;

  res.json({ success: true, data: { token } });
}

module.exports = { adminLogin };
