const crypto = require("crypto");
const { getJwtSecret } = require("../config/env");

function adminAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const [scheme, token] = header.split(" ");
  if (scheme !== "Bearer" || !token) {
    return res.status(401).json({ success: false, message: "Admin authentication required." });
  }

  try {
    const parts = token.split(".");
    if (parts.length !== 3) throw new Error("Malformed token");
    const secret = getJwtSecret();
    const unsigned = `${parts[0]}.${parts[1]}`;
    const expected = crypto.createHmac("sha256", secret).update(unsigned).digest();
    const actual = Buffer.from(parts[2], "base64url");
    if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) {
      throw new Error("Invalid signature");
    }
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
    if (payload.role !== "admin" || !payload.exp || payload.exp <= Math.floor(Date.now() / 1000)) {
      throw new Error("Invalid or expired admin token");
    }
    req.admin = payload;
    return next();
  } catch {
    return res.status(401).json({ success: false, message: "Invalid or expired admin session. Please log in again." });
  }
}

module.exports = adminAuth;
