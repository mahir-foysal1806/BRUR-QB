-- Additional additive indexes for common BRUR QB list ordering and session filtering.
-- Migration 001 already creates department, semester, course-code and report indexes.
CREATE INDEX IF NOT EXISTS questions_visible_uploaded_id_idx
  ON questions (uploaded_at DESC, id DESC)
  WHERE is_hidden = FALSE;

CREATE INDEX IF NOT EXISTS questions_session_year_idx
  ON questions (session_year);
